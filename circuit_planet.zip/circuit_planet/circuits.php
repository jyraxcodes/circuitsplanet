<?php 
namespace Jyraxcodes;

require_once __DIR__ . './lib/Pagination.php';

$paginationModel = new Pagination();
$pageResult = $paginationModel->getPage_circuits();
$queryString = "?";
if (isset($_GET["page"])) {
    $pn = $_GET["page"];
} else {
    $pn = 1;
}
$limit = Config::LIMIT_PER_PAGE;

$totalRecords = $paginationModel->getAllRecords_circuits();
$totalPages = ceil($totalRecords / $limit);

include 'includes/comp.php';
$page_name="Circuits List";
$page_address="circuits.php";
include 'includes/header.php';
	
?>
 <!-- Java Scripts -->    

<script>
	function pageValidation()
	{
		var valid=true;
		var pageNo = $('#page-no').val();
		var totalPage = $('#total-page').val();
		if(pageNo == ""|| pageNo < 1 || !pageNo.match(/\d+/) || pageNo > parseInt(totalPage)){
			$("#page-no").css("border-color","#ee0000").show();
			valid=false;
		}
		return valid;
	}
</script>
    <br /><br /><br /><br />
	<div class="container">
		<div class="row">
			<div class="col-md-8 sidebar-box ftco-animate">
				<br />
				<center><h2><?php echo $page_name?></h2></center>
				<hr>
				<div class="row">
					<?php
								$cnt=(($pn*10)-10)+1;
									if (! empty($pageResult)) {
										
										foreach ($pageResult as $row) {
											$code=$row['circuit_code'];
										
										?>
						<div class="block-25 mb-4 d-flex">
							<a class="blog-img mr-4" href="view_details.php?id=<?php echo $row['id']; ?>&title=<?php echo $row['title'];?>" style="background-image: url(images/circuits/<?php echo $row['image1'] ?>);"></a>
							<div class="text">
							  <h3 class="heading"><a href="view_details.php?id=<?php echo $row['id']; ?>&title=<?php echo $row['title'];?>"><?php echo $row['title'] ?></a></h3>
							  <div class="desc">
								<?php echo $row['summary']; ?>				
							</div>
							  <a href="view_details.php?id=<?php echo $row['id'] ?>&title=<?php echo $row['title'];?>">
							  <div class="meta">
								<div><span class="icon-calendar"></span> <?php echo $row['date_approved'] ?></div>
								<div><span class="icon-person"></span><?php echo $row['posted_by']?></div>
								<div><span class="icon-tag"></span><?php echo $row['category']?></div>
							 </div></a>
							   				
							</div>
						  </div>
								<?php }}?>
				</div>
				<!-- Pagination -->
					<?php include 'includes/pagination.php';?>
					<!-- Pagination -->
			</div> <!-- .col-md-8 -->
			<?php include 'includes/sidebox.php';?>
		</div>
	</div>
    
 <?php include 'includes/footer.php';?>
    