<?php 
include 'includes/comp.php';
$page_name="Circuit Details";
include 'includes/header.php';
if(isset($_GET['id'])){
	$cid = intval($_GET['id']);
	$dn = mysqli_query($con, 'SELECT * from circuit_cat where id="'.$cid.'"'); 
	$row = mysqli_fetch_array($dn);
	$cat_name=$row['title'];

	
?>

    <br /><br /><br /><br />
	<div class="container">
		<div class="row">
			<div class="col-md-8 sidebar-box ftco-animate">
			<br />
		<center><h2><?php echo $cat_name?> Circuits Category</h2></center>
		<hr>
				<?php
	$resultc = $con->query("SELECT * FROM circuits WHERE category='$cat_name' ORDER BY id  ASC LIMIT 10");
    if ($resultc) { 
	
        //fetch results set as object and output HTML
        while($objc = $resultc->fetch_object()) 
		{?>							
						<div class="block-21 mb-4 d-flex">
							<a class="blog-img mr-4" href="view_details.php?id=<?php echo $objc->id ?>&title=<?php echo $objc->title;?>" style="background-image: url(images/circuits/<?php echo $objc->image1 ?>);"></a>
							<div class="text">
							  <h3 class="heading"><a href="view_details.php?id=<?php echo $objc->id ?>&title=<?php echo $objc->title;?>"><?php echo $objc->title ?></h3>
							  <div class="meta">
								<div><span class="icon-calendar"></span> <?php echo $objc->date ?></div>
								<div><span class="icon-person"></span><?php echo $objc->posted_by ?></div>
								<div><span class="icon-tag"></span><?php echo $objc->category ?></div>
							  </div>
							</div></a>
						  </div>
								<?php }}?>
			</div> <!-- .col-md-8 -->
			<?php }?>
			<?php include 'includes/sidebox.php';?>
		</div>
	</div>
    
 <?php include 'includes/footer.php';?>
    