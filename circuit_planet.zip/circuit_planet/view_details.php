<?php 
include 'includes/comp.php';
$page_name="Circuit Details";
include 'includes/header.php';
if(isset($_GET['id'])){
	$id = intval($_GET['id']);
	$dn = mysqli_query($con, 'SELECT * from circuits where id="'.$id.'"'); 
	$row = mysqli_fetch_array($dn);
?>
    <br /><br /><br /><br />
	<div class="container">
		<div class="row">
			<div class="col-md-8 sidebar-box ftco-animate">
				<p>
					<h1><?php echo $row['title'];?></h1>
					<div class="meta"><font color="#ccc"><span class="icon-calendar"> <?php echo $row['date'];?></span> || <span class="icon-person"></span> <?php echo $row['posted_by'];?> || <span class="icon-tag"></span> <?php echo $row['category'];?></font></div>
					<br /><br />
					<img src="images/circuits/<?php echo $row['image1'];?>" alt="<?php echo $row['title'];?> image" class="img-fluid">
				</p>
				<h2 class="mb-3">Descriptions of <?php echo $row['title'];?> Circuit</h2>
				<p>
					<div class="row">
						<div class="col-md-8"><?php echo $row['description']?></div>
						<div class="col-md-4"><img src="images/circuits/<?php echo $row['image2'];?>" alt="<?php echo $row['title'];?> image" class="img-fluid"></div>
					</div>
				</p>
				<h2 class="mb-3">Components of Circuit</h2>
				<p>
					<div class="row">
						<div class="col-md-8"><?php echo $row['components']?></div>
					</div>
				</p>
				
				<h2 class="mb-3">Step by Step Circuit of Circuit Assembling</h2>
				<?php if ($row['image3']!=""){?>
				<p>
					<div class="row">
						<div class="col-md-4"><img src="images/circuits/<?php echo $row['image3'];?>" alt="<?php echo $row['title'];?> image" class="img-fluid"></div>
						<div class="col-md-8"><?php echo $row['steps']?></div>
					</div>
				</p>
				<?php }else{?>
				<p>
					<div class="row">
						<div class="col-md-8"><?php echo $row['steps']?></div>
					</div>
				</p> 
				<?php } ?>
			</div> <!-- .col-md-8 -->
			<?php } ?>
			<?php include 'includes/sidebox.php';?>
		</div>
	</div>
</section> <!-- .section -->
    
 <?php include 'includes/footer.php';?>
    