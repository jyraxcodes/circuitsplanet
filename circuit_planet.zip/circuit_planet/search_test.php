<?php

	namespace Jyraxcodes;

require_once __DIR__ . './includes/lib/Pagination.php';

$paginationModel = new Pagination();
$pageResult = $paginationModel->getPage();
$queryString = "?";
if (isset($_GET["page"])) {
    $pn = $_GET["page"];
} else {
    $pn = 1;
}
$limit = Config::LIMIT_PER_PAGE;

$totalRecords = $paginationModel->getAllRecords();
$totalPages = ceil($totalRecords / $limit);
$page_name='search';
 include 'includes/header.php'; 
	if (isset($_POST['search'])) {
  require "includes/searchprod.php";
}
    if (isset($_POST['search'])) {
		$countres=count($results);
		if ($countres > 0) {
?>
    <!-- ##### Shop Grid Area Start ##### -->
    <section class="shop_grid_area section-padding-80">
        <div class="container">
            <div class="row">
                <?php include'includes/sidebar.php';?>

                <div class="col-12 col-md-8 col-lg-9">
                    <div class="shop_grid_product_area">
                        <div class="cart-page-heading mb-30">
							<i><?php echo $countres;?> Products found</i> 
						</div>
						<div class="row">		
							<?php
										$cnt=0;
         foreach ($results as $r) {
			 			 $cnt=+$cnt+1;
         $idprod=$r['id'];
		 $nameprod=$r['product_name'];
         $image1=$r['image1'];
         $image2=$r['image2'];
         $codeprod=$r['product_code'];
		 $catprod=$r['category'];
		 $brand=$r['brand'];
		 $sizeprod=$r['size'];
		 $price1=$r['price1'];
		 $price2=$r['price2'];
		$percent=$r['percent'];
		 ?>
		 
		
                            <!-- Single Product -->
							<div class="col-12 col-sm-6 col-lg-4">
							   <?php echo $cnt;?>. 
                                <div class="single-product-wrapper">
                                    <!-- Product Image -->
                                    <div class="product-img">
                                        <img src="img/products/<?php echo $image1;?>" alt="">
                                        <!-- Hover Thumb -->
                                        <img class="hover-img" src="img/products/<?php echo $image2;?>" alt="">

                                        <!-- Product Badge -->
                                        <?php
								if ($percent>=4){
									?>
                                <!-- Product Badge -->
                                <div class="product-badge offer-badge">
                                    <span>-<?php echo $percent;?>%</span>
                                </div>
								<!-- Favourite -->
                                <div class="product-favourite">
                                    <a href="#" class="favme fa fa-heart"></a>
                                </div>
								<?php }else{
									?>
                                        <!-- Favourite -->
                                        <div class="product-favourite">
                                            <a href="#" class="favme fa fa-heart"></a>
                                        </div>
								<?php
								} ?>
                                    </div>

                                    <!-- Product Description -->
                                    <div class="product-description">
                                        <span><?php echo $brand;?></span>
                                        <a href="view_details.php?id=<?php echo $idprod;?>">
                                            <h6><?php echo $nameprod; ?></h6>
                                        
                                        <?php
								if (($price1-$price2)>=(0.05*$price1)){
									?><span class="old-price">&#8358;<?php echo $price1;?></span> &#8358;<?php echo $price2;?>
								<?php }else { ?> &#8358;<?php echo $price2; }?> </p>
										</a>
                                        <!-- Hover Content -->
                                        <div class="hover-content">
                                            <!-- Add to Cart -->
                                            <div class="add-to-cart-btn">
                                                <a href="#" class="btn essence-btn">Add to Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
				<?php 

	}
	?>
						</div>
                    </div>
                    <!-- Pagination -->
                                        <!-- Pagination -->
					
					<nav aria-label="navigation">
                        <ul class="pagination">
                     <?php
						if (($r > 1) && ($pn > 1)) {
						?>
							<li class="page-item"><a class="page-link" href="<?php echo $queryString;?>page=<?php echo (($pn-1));?>"><i class="fa fa-angle-left"></i></a></li>
					<?php }?>
					<?php
						if (($pn - 1) > 1) {
						?>
							<li class="page-item"><a class="page-link" a href='search.php?page=1'>1</a></li>
							<li class="page-item"><a class="page-link" href="#">...</a></li>
					<?php
					}

						for ($i = ($pn - 1); $i <= ($pn + 1); $i ++) {
							if ($i < 1)
								continue;
							if ($i > $totalPages)
								break;
							if ($i == $pn) {
								$class = "active";
							} else {
								$class = "page-link";
							}
						?>
							<li class="page-item"><a class="page-link" href='search.php?page=<?php echo $i; ?>'><div class='<?php echo $class; ?>'><?php echo $i; ?></div></a></li>
					<?php
					}
						if (($totalPages - ($pn + 1)) >= 1) {
					?>
							<li class="page-item"><a class="page-link" href="#">...</a></li>
					<?php
					}
						if (($totalPages - ($pn + 1)) > 0) {
							if ($pn == $totalPages) {
								$class = "active";
							} else {
								$class = "page-link";
						}
					?>
							<a href='search.php?page=<?php echo $totalPages; ?>'><div
                        class='<?php echo $class; ?>'><?php echo $totalPages; ?></div></a> 
					<?php
					}
					?>
					<?php
						if (($r > 1) && ($pn < $totalPages)) {
					?>
							<li class="page-item"><a class="page-link" href="<?php echo $queryString;?>page=<?php echo (($pn+1));?>"><i class="fa fa-angle-right"></i></a></li> 
					<?php
					}
					?>
                        </ul>
                    </nav>
					<!-- Pagination -->
					
                </div>
				
				</div>
	<?php
      } else {
		  ?>
		  <section class="shop_grid_area section-padding-80">
        <div class="container">
            <div class="row">
                <?php include'includes/sidebar.php';?>

                <div class="col-12 col-md-8 col-lg-9">
                    <div class="shop_grid_product_area">
                        <div class="cart-page-heading mb-30">
							<i><?php echo $countres;?> Products found</i> 
						</div>
						<div class="row">	
        <?php echo "No results found";
      }
    }
    ?>
	</div>
	 </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
<?php include 'includes/footer.php'?>