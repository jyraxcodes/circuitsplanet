<?php 
include 'includes/comp.php';
$page_name="Books";
include 'includes/header.php';
if(isset($_GET['id'])){
	$id = intval($_GET['id']);
	$dn = mysqli_query($con, 'SELECT * from books where id="'.$id.'"'); 
	$row = mysqli_fetch_array($dn);
?>
    <br /><br /><br /><br />
	<div class="container">
		<div class="row">
			<div class="col-md-8 sidebar-box ftco-animate">
				<table border="0" style="padding:6px;">
					<tr>
						<td width="400px">
							<img src="images/books/<?php echo $row['image'];?>" height="200px" width="200px" alt="<?php echo $row['title'];?>"><br />
							<br />
							<i class="icon-user"></i> Author: <?php echo $row['author'];?><br />
							<br />
								<?php if ($row['price']<=1){ ?>
							<i class="icon-money"></i> Price: Free <br />
								<?php }else{ ?>
							<i class="icon-money"></i> Price: <?php echo $row['price'];?><br />
								<?php } ?>
						</td>
						<td width="400px">
						<h5><?php echo $row['title'];?></h5>
							<?php echo $row['description']?>
						</td>
					</tr>
				</table>
			</div> <!-- .col-md-8 -->
				<?php } ?>
				<?php include 'includes/sidebox.php';?>
		</div>
	</div>
</section> <!-- .section -->
    
 <?php include 'includes/footer.php';?>
    