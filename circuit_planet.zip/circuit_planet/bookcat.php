<?php 
include 'includes/comp.php';
$page_name="Books Category";
include 'includes/header.php';
if(isset($_GET['id'])){
	$cid = intval($_GET['id']);
	$dn = mysqli_query($con, 'SELECT * from book_cat where id="'.$cid.'"'); 
	$row = mysqli_fetch_array($dn);
	$cat_name=$row['title'];

	
?>

    <br /><br /><br /><br />
	<div class="container">
		<div class="row">
			<div class="col-md-8 sidebar-box ftco-animate">
				<br />
				<center><h2><?php echo $cat_name?> Books Category</h2></center>
				<hr>
				<div class="row">
					<?php
					$resultc = $con->query("SELECT * FROM books WHERE category='$cat_name' ORDER BY id  ASC LIMIT 10");
					if ($resultc) { 

					//fetch results set as object and output HTML
					while($objc = $resultc->fetch_object()) 
					{?>	
					<div class="col-md-4 ftco-animate">
						<div class="blog-entry">
							<a href="view_book.php?id=<?php echo $objc->id ?>&title=<?php echo $objc->title;?>" class="block-20" style="background-image: url('images/books/<?php echo $objc->image;?>');"></a>
							<div class="text p-4 d-block">
								<div class="meta mb-3">
									<div><span class="icon-pencil"></span> <?php echo $objc->author ?></div>
									<div><span class="icon-doc-pdf"></span></div>
									<div><span class="icon-money"></span><?php echo $objc->price ?></div>
								</div>
								<h3 class="heading"><a href="#"><?php echo $objc->title;?></a></h3>
							</div>
						</div>
					</div>
					<?php }}?>
				</div>
			</div> <!-- .col-md-8 -->
			<?php }?>
			<?php include 'includes/sidebox.php';?>
		</div>
	</div>
    
 <?php include 'includes/footer.php';?>
    