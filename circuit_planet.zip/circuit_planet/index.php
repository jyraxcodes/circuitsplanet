<?php 

	include "includes/comp.php";
	$page_name="Home";
	$page_address="index.php";
	include "includes/header.php";

 ?>
    
    <!-- <div class="js-fullheight"> -->
    <div class="hero-wrap" style="height: 485px;">
      <div class="overlay"></div>
      <div id="particles-js"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center" data-scrollax-parent="true">
          <div class="col-md-6 ftco-animate text-center" data-scrollax=" properties: { translateY: '70%' }">
            <h1 class="mb-4" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">We love to Design <strong>Beautiful</strong> Circuits</h1>
            <p data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><a href="#" class="btn btn-primary btn-outline-white px-5 py-3">Forum</a></p>
          </div>
        </div>
      </div>
    </div>
    
    <div class="bg-light">
    <section class="ftco-section-featured ftco-animate">
      <div class="container-fluid" data-scrollax-parent="true">
        <div class="row no-gutters d-flex align-items-center" data-scrollax=" properties: { translateY: '-30%'}">
<br/><br/><br/><br/><br/><br/><br/>
        </div>
		<section class="ftco-section ftco-degree-bg">
			<div class="container">
				<div class="row">
					<div class="col-md-12 sidebar-box ftco-animate">
						<center><h2 class="mb-3">Featured Ciruits</h2></center>
							
  <?php
	$resultsc = $con->query("SELECT * FROM circuits ORDER BY id DESC limit 10");
    if ($resultsc) { 
	
        //fetch results set as object and output HTML
        while($objc = $resultsc->fetch_object()) 
		{?>							
						<div class="block-21 mb-4 d-flex">
							<a class="blog-img mr-4" href="view_details.php?id=<?php echo $objc->id ?>&title=<?php echo $objc->title;?>" style="background-image: url(images/circuits/<?php echo $objc->image1 ?>);"></a>
							<div class="text">
							  <h3 class="heading"><a href="view_details.php?id=<?php echo $objc->id ?>&title=<?php echo $objc->title;?>"><?php echo $objc->title ?></h3>
							  <div class="meta">
								<div><span class="icon-calendar"></span> <?php echo $objc->date ?></div>
								<div><span class="icon-person"></span><?php echo $objc->posted_by ?></div>
								<div><span class="icon-tag"></span><?php echo $objc->category ?></div>
							  </div>
							</div></a>
						  </div>
								<?php }}?>

					</div>
					
				</div>
			</div>
		</section>
		  <section class="ftco-section ftco-counter" id="section-counter">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-5">
          <div class="col-md-7 text-center heading-section heading-section-white ftco-animate">
            <h2>Latest updates</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6 col-lg-4 d-flex justify-content-center counter-wrap ftco-animate">
            <div class="block-18 text-center">
              <div class="text">
                <strong class="number" data-number="<?php echo $countCir ?>">0</strong>
                <span>Circuits</span>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex justify-content-center counter-wrap ftco-animate">
            <div class="block-18 text-center">
              <div class="text">
                <strong class="number" data-number="<?php echo $countProj ?>">0</strong>
                <span>Projects Topics</span>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex justify-content-center counter-wrap ftco-animate">
            <div class="block-18 text-center">
              <div class="text">
                <strong class="number" data-number="<?php echo $countBks ?>">0</strong>
                <span>Books</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

      </div>
    </section>
    </div>
 <?php include "includes/footer.php"; ?>