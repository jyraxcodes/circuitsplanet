<?php 
namespace Jyraxcodes;

require_once __DIR__ . './lib/Pagination.php';

$paginationModel = new Pagination();
$pageResult = $paginationModel->getPage_books();
$queryString = "?";
if (isset($_GET["page"])) {
    $pn = $_GET["page"];
} else {
    $pn = 1;
}
$limit = Config::LIMIT_PER_PAGE;

$totalRecords = $paginationModel->getAllRecords_books();
$totalPages = ceil($totalRecords / $limit);

include 'includes/comp.php';
$page_name="Engineering Books";
$page_address="books.php";
include 'includes/header.php';
	
?>
 <!-- Java Scripts -->    

<script>
	function pageValidation()
	{
		var valid=true;
		var pageNo = $('#page-no').val();
		var totalPage = $('#total-page').val();
		if(pageNo == ""|| pageNo < 1 || !pageNo.match(/\d+/) || pageNo > parseInt(totalPage)){
			$("#page-no").css("border-color","#ee0000").show();
			valid=false;
		}
		return valid;
	}
</script>
    <br /><br /><br /><br />
	<div class="container">
		<div class="row">
			<div class="col-md-8 sidebar-box ftco-animate">
				<br />
				<center><h2><?php echo $page_name?></h2></center>
				<hr>
				<div class="row">
					<?php
								$cnt=(($pn*10)-10)+1;
									if (! empty($pageResult)) {
										
										foreach ($pageResult as $row) {
										
										?>
					<div class="col-md-4 ftco-animate">
						<div class="blog-entry">
							<a href="view_book.php?id=<?php echo $row['id'] ?>&title=<?php echo $row['title'] ?>" class="block-20" style="background-image: url('images/books/<?php echo $row['image'] ?>');"></a>
							<div class="text p-4 d-block">
								<div class="meta mb-3">
									<div><span class="icon-pencil"></span> <?php echo $row['author'] ?></div>
									<div><span class="icon-doc-pdf"></span></div>
									<div><span class="icon-money"></span><?php echo $row['price'] ?></div>
								</div>
								<h3 class="heading"><a href="view_book.php?id=<?php echo $row['id'] ?>&title=<?php echo $row['title'] ?>"><?php echo $row['title'] ?></a></h3>
							</div>
						</div>
					</div>
								<?php }}?>
				</div>
				<!-- Pagination -->
					<?php include 'includes/pagination.php';?>
					<!-- Pagination -->
			</div> <!-- .col-md-8 -->
			<?php include 'includes/sidebox.php';?>
		</div>
	</div>
    
 <?php include 'includes/footer.php';?>
    