<?php 
namespace Jyraxcodes;
require_once __DIR__ . './includes/lib/Pagination.php';
$paginationModel = new Pagination();
$pageResult = $paginationModel->getPage_search();
$queryString = "?";
if (isset($_GET["page"])) {
    $pn = $_GET["page"];
} else {
    $pn = 1;
}
$limit = Config::LIMIT_PER_PAGE;

$totalRecords = $paginationModel->getAllRecords_search();
$totalPages = ceil($totalRecords / $limit);
session_start();
error_reporting(0);
$page_name='search';
include 'includes/config.php';
include 'includes/header.php';
	if (isset($_POST['search'])) {
		require "includes/searchsite.php";
		}
	

  

?>
				<br /><br /><br /><br /><br />
				<div class="container">
					<div class="row">
						<div class="col-md-8 sidebar-box ftco-animate">
							<?php 
							if (isset($_POST['search'])) {
								$countres=count($results);
								if ($countres > 0) { ?>
							<h3><i><?php echo $countres;?> Products found</i> </h3>
						
							<div class="row">		
								<?php
								
									$cnt=0;
									foreach ($results as $r) {
									$cnt=+$cnt+1;
									$id=$r['id'];
									$title=$r['title'];
									$category=$r['category'];
									$posted_by=$r['posted_by'];
									$gate=$r['date'];
									$image=$r['image'];
								?>
								<div class="block-21 mb-4 d-flex">
									<a class="blog-img mr-4" href="view_details.php?id=<?php echo $id ?>&title=<?php echo $title;?>" style="background-image: url(images/circuits/<?php echo $image1 ?>);"></a>
									<div class="text">
									  <h3 class="heading"><a href="view_details.php?id=<?php echo $id ?>&title=<?php echo $title;?>"><?php echo $title ?></h3>
									  <div class="meta">
										<div><span class="icon-calendar"></span> <?php echo $date ;?></div>
										<div><span class="icon-person"></span><?php echo $posted_by ;?></div>
										<div><span class="icon-tag"></span><?php echo $category ;?></div>
									  </div>
									</div></a>
								</div>
								<?php }?>
								 <?php include 'includes/pagination.php';
								 ?>
							</div>		
							<?php
							} else {
									 echo "No results found";
								  }?>
						</div> <!-- .col-md-8 -->
						<?php include 'includes/sidebox.php';?>
					</div>
				</div>
<?php }
										?>
						 

    
 <?php include 'includes/footer.php';?>
    