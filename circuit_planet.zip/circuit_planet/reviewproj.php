<?php 
session_start();
error_reporting(0);
include 'techie/includes/admin_details.php';
$page_name="Review Project Page";
include 'includes/config.php';
include 'includes/header.php';
if(isset($_GET['id']))
{
	$id = intval($_GET['id']);
		$dn = mysqli_query($con, 'SELECT * from projects_review where id="'.$id.'"'); 
		$row = mysqli_fetch_array($dn);
		
		$page_address="reviewproj.php?id=".$id;	
		$code=stripslashes($row['circuit_code']);
		$title=stripslashes($row['title']);
		$cat=stripslashes($row['category']);
		$desc=stripslashes($row['description']);
		$comp=stripslashes($row['components']);
		$steps=stripslashes($row['steps']);
		$adminr=stripslashes($adminCode);
		$image1=stripslashes($row['image1']);
		$doc=stripslashes($row['document']);
		$posted_by=stripslashes($row['posted_by']);
		if(isset($_POST['approved'])){
		$sql = "INSERT INTO projects SET project_code='$code', title='$title', category='$cat',description='$desc', price='$price', image='$image', document='$doc', posted_by='$posted_by', approved_by='$adminr'";
		if(mysqli_query($con, $sql)){
			echo "<script>alert('Project Approved Successfully');</script>";
			echo "<script>window.location.href ='$page_address'</script>";
		} else{
		  echo "<script>alert('Error: There was a posting page. Please try again.');</script>"; 
		}
	}
?>
    <br /><br /><br /><br /><br />
	<div class="container">
		<div class="row">
			<div class="col-md-8 sidebar-box ftco-animate">
				<p>
					<h1><?php echo $row['title'];?></h1>
					<div class="meta"><font color="#ccc"><span class="icon-calendar"> <?php echo $row['date'];?></span> || <span class="icon-person"></span> <?php echo $row['posted_by'];?> || <span class="icon-tag"></span> <?php echo $row['category'];?></font></div>
					<br /><br />
					<img src="images/projects/<?php echo $row['image'];?>" alt="<?php echo $row['title'];?> image" class="img-fluid">
				</p>
				<h4 class="mb-3">About <?php echo $row['title'];?> </h4>
				<p>
						<div class="col-md-8"><?php echo $row['description']?></div>
					
				</p> 
				<div class="row">			
				<?php
				$result1 = mysqli_query($con,"SELECT * FROM projects where project_code='$code'");
					$num_rows1 = mysqli_num_rows($result1);
					{ 
					$countres1=htmlentities($num_rows1);  }	
				if (($row['posted_by']!=$adminCode) AND ($countres1 == 0)) { ?>
					<div class="col-md-4"><a href="techie/edit_project.php?id=<?php echo $id;?>"><button class="btn btn-success btn-xs">Edit Page</button></a></div>
					<form method="POST">
						<div class="col-md-4">
							<button name="approved" type="submit" class="btn btn-success btn-xs"><i class="icon-database"></i>Approve Page</button>
						</div>	
					</form>
				<?php }
				else{
					?>
					<div class="col-md-6">
						<?php if ($countres1 ==1){
							?>
							<font class="btn btn-success btn-xs"><i class="icon-thumbs-up"></i>This page has been approved</font>
											
					<?php 	}?>
					</div>
					<?php		}?>
					<div class="col-md-2">
						<a href="techie/manage_projects.php"><button class="btn btn-warning btn-xs">Manage Projects</button></a>
					</div>
					</div>
				<?php } ?>
			</div> <!-- .col-md-8 -->
			<?php include 'includes/sidebox.php';?>
		</div>
	</div>
</section> <!-- .section -->
    
 <?php include 'includes/footer.php';?>
    